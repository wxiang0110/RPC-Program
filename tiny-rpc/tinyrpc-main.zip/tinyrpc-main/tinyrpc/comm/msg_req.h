#ifndef TINYRPC_COMM_MSG_REQ_H
#define TINYRPC_COMM_MSG_REQ_H

#include <string>

namespace tinyrpc {

class MsgReqUtil {
 public:
  static std::string genMsgNumber();

};


}


#endif