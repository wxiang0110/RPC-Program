# LittleRpc
An rpc component based on C++ and python zmq, cross language communication, simple and easy to use
